const express = require('express')
const app = express()
const request = require('request');
const fs    = require('fs');
var bodyParser = require('body-parser');

var certpks = fs.readFileSync(process.env.IOT_P12_CERT);
var pass = process.env.IOT_CERT_SECRET;

//To Support body on post requests
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

//IOT_CF_URL: "https://trial.canary.cp.iot.sap/iot/gateway/rest/measures/SMBIoTSensorTagDevice"

/* TRM Sensor
    IOT_CF_URL: "https://49846596-cc03-4386-9f33-0c2b1641465c.eu10.cp.iot.sap/iot/gateway/rest/measures/059deb07-b2d9-456c-9a21-16bf708008ab"
    IOT_P12_CERT: "SMB IoT SensorTag Device-device_certificate.p12"
    IOT_CERT_SECRET: "HwunZga4oqYn9tz9PlF11JOFkfvNRvkxNTzv"
    IOT_CAPABILITY_ALT_ID: "295008713"
    IOT_SENSOR_ALT_ID: "3b3b82ec-9739-43e4-b5dd-f20fd069b5cb"
*/
/* Sensor Hackathon 1
    IOT_CF_URL: "https://49846596-cc03-4386-9f33-0c2b1641465c.eu10.cp.iot.sap/iot/gateway/rest/measures/f5968ffa-2ea7-456c-8af1-e77032504f03"
    IOT_P12_CERT: "SMB IoT SensorTag Device 1-device_certificate.p12"
    IOT_CERT_SECRET: "LKq0KcQnoup2ryfMN7sfy8FXrxBVneVCbI03"
    IOT_CAPABILITY_ALT_ID: "295008713"
    IOT_SENSOR_ALT_ID: "SMBIoTSensorTagSensor1"
*/

app.post('/Stream', function (req, res) {
    console.log("Stream body " + JSON.stringify(req.body));
    var x = {};
    x = req.body;
    m1 = x.dev;
    m2 = x.accx;
    m3 = x.accy;
    m4 = x.accz;
    m5 = x.alt;
    m6 = x.lng;
    m7 = x.lat;
    m8 = x.lux;

    //  POST Sensor Data
    const options = {
      method: "POST",
      url: process.env.IOT_CF_URL,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({"capabilityAlternateId":process.env.IOT_CAPABILITY_ALT_ID,"measures":[m1,m2,m3,m4,m5,m6,m7,m8],"sensorAlternateId":process.env.IOT_SENSOR_ALT_ID}),
      agentOptions: {
          pfx: certpks,
          passphrase: pass
        }
    };
    //console.log("OPTIONS " + JSON.stringify(options));

    request(options, callback);

    res.setHeader('Content-Type', 'application/json')
    res.status(200)
    res.send(JSON.stringify(req.body))

});

function callback(error, response, body) {
  console.log("RESPONSE " + response.statusCode + " " + JSON.stringify(response.body));
  if (!error && response.statusCode == 200 || response.statusCode == 202) {
    const info = JSON.parse(body);
    console.log("RESPONSE" + JSON.stringify(info));
  }
}

//Gets port from environment of use default
var port = process.env.PORT || 30000
app.listen(port, function () {
    console.log('Iot Gateway CF App running on port ' + port);
});
